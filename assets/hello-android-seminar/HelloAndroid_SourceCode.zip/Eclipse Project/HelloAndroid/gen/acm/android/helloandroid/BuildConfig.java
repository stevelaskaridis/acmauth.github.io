/** Automatically generated file. DO NOT MODIFY */
package acm.android.helloandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}