package acm.android.helloandroid;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends Activity {

	private Button bLaunchAct, bSendText, bExit, bKill;
	private EditText etSend;
	private TextView tvReply;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		init();
	}

	private void init() {
		bLaunchAct = (Button) findViewById(R.id.blaunchact);
		bSendText = (Button) findViewById(R.id.bsendtext);
		bExit = (Button) findViewById(R.id.bexit);
		bKill = (Button) findViewById(R.id.bkill);
		
		etSend = (EditText) findViewById(R.id.etsend);
		tvReply = (TextView) findViewById(R.id.tvreply);

		tvReply.setVisibility(View.INVISIBLE);
		
		bLaunchAct.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(Home.this, MyActivity.class);
				startActivity(i);
			}
		});
		
		bSendText.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(Home.this, TextReply.class);
				i.putExtra("text", etSend.getText().toString());
				startActivityForResult(i, 1);
			}
		});
		
		bExit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish(); 
			}
		});
		
		bKill.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				System.exit(0);
			}
		});
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == 1) {
			String reply = data.getStringExtra("reply");
			tvReply.setVisibility(View.VISIBLE);
			tvReply.setText(reply);
		} else {
			Toast.makeText(this, "Something went wrong...", Toast.LENGTH_SHORT)
					.show();
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

}
