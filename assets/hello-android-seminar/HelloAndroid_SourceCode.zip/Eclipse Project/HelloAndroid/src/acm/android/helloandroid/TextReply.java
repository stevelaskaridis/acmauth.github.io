package acm.android.helloandroid;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TextReply extends Activity{
	
	private Button bReply;
	private TextView tvText;
	private String text;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.textreply); 
		
		text = getIntent().getStringExtra("text");
		init();
	}

	private void init() {
		tvText = (TextView) findViewById(R.id.tvtext);		
		bReply = (Button) findViewById(R.id.breply);

		tvText.setText(text);
		bReply.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent data = new Intent();
				if (text.equals("hi")) {
					data.putExtra("reply", "Reply: Hello!");
					setResult(1, data);					
				} else if(text.equals("how are you?")) {
					data.putExtra("reply", "Reply: Fine thanks!");
					setResult(1, data);					
				} else if(!text.equals("")) {	
					data.putExtra("reply", "Reply: " + text.toUpperCase());
					setResult(1, data);
				} else {
					setResult(0);
				}
				finish();
				
			}
		}); 

	}
	
}
