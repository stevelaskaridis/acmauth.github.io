package acm.android.helloandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button; 
import android.widget.TextView;

public class MyActivity extends Activity{
	
	private Button bPlus, bMinus;
	private TextView tvNumber;
	
	private static int storedNumber = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myactivity);
		init();
		} 

		private void init() {
			tvNumber = (TextView) findViewById(R.id.tvnumber);
			bPlus = (Button) findViewById(R.id.bplus);
			bMinus = (Button) findViewById(R.id.bminus);
			 
			tvNumber.setText( String.valueOf(storedNumber) );
			
			bPlus.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					String sNumber = tvNumber.getText().toString();
					int number = Integer.parseInt( sNumber );
					tvNumber.setText( String.valueOf(number + 1) );
					storedNumber += 1;
				}
			});
			
			bMinus.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					String sNumber = tvNumber.getText().toString();
					int number = Integer.parseInt( sNumber );
					tvNumber.setText( String.valueOf(number - 1) );
					storedNumber -= 1;
				}
			});
		}
	
}
